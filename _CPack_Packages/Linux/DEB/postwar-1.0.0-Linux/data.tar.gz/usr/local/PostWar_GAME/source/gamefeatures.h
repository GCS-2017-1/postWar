#ifndef GAMEFEATURES_H
#define GAMEFEATURES_H

#include <SDL/SDL.h>

extern void load_menu(SDL_Surface *screen);
extern void inicio(SDL_Surface *screen);
extern void creditos(SDL_Surface *screen);

#endif
