/*
 * Autor: Edson Alves
 * Data: 26/12/2012
 * e-mail: edsonalves@unb.br
 */
#include <iostream>
#include <cstdlib>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "video.h"

using namespace std;

void init_audio()
{

}
