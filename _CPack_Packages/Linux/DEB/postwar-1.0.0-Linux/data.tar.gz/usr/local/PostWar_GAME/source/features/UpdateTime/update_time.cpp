#include <iostream>

void update_time()
{

}
