#include <iostream>

void Time()
{

}
