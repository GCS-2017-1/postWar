#include <iostream>

void simulated_World()
{

}
